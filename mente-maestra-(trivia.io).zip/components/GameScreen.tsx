import React from 'react';
import { Player, QuestionData } from '../types';
import QuestionCard from './QuestionCard';
import Button from './Button'; // Import Button component
import { TEXT_NEON_PINK, TEXT_NEON_BLUE, TITLE_FONT_FAMILY } from '../constants';

interface GameScreenProps {
  players: Player[];
  questions: QuestionData[];
  currentQuestionIndex: number;
  onAnswer: (selectedAnswer: string) => void;
  isAnswerRevealed: boolean;
  selectedAnswer: string | null;
  topics: string[];
  totalGameQuestions: number;
  onEndGameEarly: () => void; 
}

const GameScreen: React.FC<GameScreenProps> = ({
  players,
  questions,
  currentQuestionIndex,
  onAnswer,
  isAnswerRevealed,
  selectedAnswer,
  topics,
  totalGameQuestions,
  onEndGameEarly,
}) => {
  const currentPlayerIndex = currentQuestionIndex % players.length;
  const currentPlayer = players[currentPlayerIndex];
  const currentQuestion = questions[currentQuestionIndex];

  if (!currentQuestion) {
    return <div className="text-center p-8 text-xl">Cargando siguiente pregunta o finalizando...</div>;
  }

  const handleEndGameClick = () => {
    if (window.confirm("¿Seguro que quieres terminar la partida? Se mostrarán los resultados actuales.")) {
      onEndGameEarly();
    }
  };

  const getPlayerCardClass = (player: Player, index: number) => {
    let baseClass = `w-40 p-3 rounded-lg text-center transition-all duration-300`; 
    if (player.name === currentPlayer.name && player.avatarId === currentPlayer.avatarId) {
      baseClass += index % 2 === 0 ? ` bg-pink-600/40 ${TEXT_NEON_PINK} border-2 border-pink-500 shadow-[0_0_15px_1px_rgba(255,0,255,0.5)]` : ` bg-cyan-500/40 ${TEXT_NEON_BLUE} border-2 border-cyan-400 shadow-[0_0_15px_1px_rgba(0,255,255,0.5)]`;
    } else {
      baseClass += ` bg-slate-700/50 border-2 border-slate-600 opacity-70`;
    }
    return baseClass;
  };


  return (
    <div className="flex flex-col items-center justify-start min-h-screen p-4 pt-6 md:pt-10 w-full">
      <div className="w-full max-w-3xl mb-6 text-center">
        <h2 className={`${TITLE_FONT_FAMILY} text-lg md:text-xl font-bold mb-1 ${TEXT_NEON_BLUE}`}>
          Temas: {topics.join(', ')}
        </h2>
        <div className="flex flex-wrap justify-center items-stretch gap-2 md:gap-4 text-base md:text-lg font-semibold bg-slate-800/70 p-2 md:p-3 rounded-lg mb-4">
          {players.map((player, index) => (
            <div key={`${player.name}-${player.avatarId}`} className={getPlayerCardClass(player, index)}>
              <div className="flex items-center justify-center md:justify-start">
                <span className="text-3xl md:text-4xl mr-2">{player.avatarId}</span>
                <div className="text-left">
                  <span className={`block truncate max-w-[80px] md:max-w-[120px] font-bold ${player.name === currentPlayer.name && player.avatarId === currentPlayer.avatarId ? 'text-white' : (index % 2 === 0 ? TEXT_NEON_PINK : TEXT_NEON_BLUE) }`}>{player.name}</span>
                  <span className="text-white text-sm md:text-base">{player.score} pts</span>
                </div>
              </div>
            </div>
          ))}
        </div>
        <p className={`mt-2 text-xl font-bold ${currentPlayerIndex % 2 === 0 ? TEXT_NEON_PINK : TEXT_NEON_BLUE}`}>
          Turno de: <span className="text-2xl">{currentPlayer.avatarId}</span> {currentPlayer.name}
        </p>
      </div>

      <QuestionCard
        question={currentQuestion}
        onAnswer={onAnswer}
        isAnswerRevealed={isAnswerRevealed}
        selectedAnswer={selectedAnswer}
        questionNumber={currentQuestionIndex + 1}
        totalQuestions={totalGameQuestions}
      />

      <div className="mt-8 w-full max-w-2xl flex justify-center">
        <Button 
            onClick={handleEndGameClick} 
            variant={currentPlayerIndex % 2 === 0 ? "blue" : "pink"} // Alternate color
            className="text-sm py-2 px-4 opacity-80 hover:opacity-100"
        >
          Terminar Partida
        </Button>
      </div>
    </div>
  );
};

export default GameScreen;