
import React from 'react';
import { NEON_PINK, NEON_BLUE } from '../constants'; // Import actual color hex values

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  variant?: 'pink' | 'blue';
  className?: string;
}

const Button: React.FC<ButtonProps> = ({ children, variant = 'pink', className = '', ...props }) => {
  const baseStyle = "px-6 py-3 font-semibold rounded-lg transition-all duration-300 ease-in-out transform hover:scale-105 focus:outline-none focus:ring-2";
  
  let variantStyle = '';
  let hoverShadowClass = '';

  if (variant === 'pink') {
    variantStyle = `bg-[${NEON_PINK}] text-slate-900 border-2 border-[${NEON_PINK}]`;
    hoverShadowClass = `hover:shadow-[0_0_15px_2px_rgba(255,0,255,0.7)] focus:ring-[${NEON_PINK}]`; // Pink hex #ff00ff
  } else { // blue
    variantStyle = `bg-[${NEON_BLUE}] text-slate-900 border-2 border-[${NEON_BLUE}]`;
    hoverShadowClass = `hover:shadow-[0_0_15px_2px_rgba(0,255,255,0.7)] focus:ring-[${NEON_BLUE}]`; // Blue hex #00ffff
  }

  // Tailwind JIT needs to see full class names. Dynamic class concatenation with arbitrary values like `bg-[${NEON_PINK}]` works.
  // The hover shadow classes are defined with rgba values to ensure they work correctly.

  return (
    <button
      className={`${baseStyle} ${variantStyle} ${hoverShadowClass} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
};

export default Button;
