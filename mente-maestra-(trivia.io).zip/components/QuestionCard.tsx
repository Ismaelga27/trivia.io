
import React from 'react';
import { QuestionData } from '../types';
import { NEON_BLUE, NEON_GREEN, NEON_RED, TEXT_NEON_BLUE, BORDER_NEON_BLUE } from '../constants';

interface QuestionCardProps {
  question: QuestionData;
  onAnswer: (selectedAnswer: string) => void;
  isAnswerRevealed: boolean;
  selectedAnswer: string | null;
  questionNumber: number;
  totalQuestions: number;
}

const QuestionCard: React.FC<QuestionCardProps> = ({
  question,
  onAnswer,
  isAnswerRevealed,
  selectedAnswer,
  questionNumber,
  totalQuestions
}) => {
  const getButtonClass = (option: string) => {
    let classes = `w-full text-left p-4 my-2 rounded-lg border-2 transition-all duration-300 ease-in-out transform hover:scale-103 ${BORDER_NEON_BLUE} text-white hover:bg-cyan-500/30`;

    if (isAnswerRevealed) {
      if (option === question.correctAnswer) {
        classes = `w-full text-left p-4 my-2 rounded-lg border-2 bg-green-500/80 border-green-400 text-white font-bold scale-105`; // Correct answer
      } else if (option === selectedAnswer) {
        classes = `w-full text-left p-4 my-2 rounded-lg border-2 bg-red-600/80 border-red-500 text-white font-bold`; // Incorrectly selected
      } else {
         classes = `w-full text-left p-4 my-2 rounded-lg border-2 border-slate-700 text-slate-400 opacity-70`; // Other incorrect options
      }
    } else if (selectedAnswer === option) {
        classes += ` ring-4 ring-offset-2 ring-offset-slate-900 ring-[${NEON_BLUE}] bg-cyan-500/40`; // Selected but not yet revealed
    }
    return classes;
  };

  return (
    <div className={`bg-slate-800/80 p-6 md:p-8 rounded-xl shadow-xl w-full max-w-2xl border ${BORDER_NEON_BLUE} ${isAnswerRevealed ? 'neon-shadow-blue' : ''}`}>
      <p className={`mb-2 text-sm ${TEXT_NEON_BLUE}`}>Pregunta {questionNumber}/{totalQuestions}</p>
      <h2 className="text-2xl md:text-3xl font-bold mb-6 text-white leading-tight" style={{ fontFamily: "'Montserrat', sans-serif" }}>
        {question.questionText}
      </h2>
      <div className="space-y-3">
        {question.options.map((option, index) => (
          <button
            key={index}
            onClick={() => !isAnswerRevealed && onAnswer(option)}
            className={getButtonClass(option)}
            disabled={isAnswerRevealed}
            style={{ minHeight: '60px' }} // Ensure consistent button height
          >
            {option}
          </button>
        ))}
      </div>
    </div>
  );
};

export default QuestionCard;
