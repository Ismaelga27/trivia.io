
// Basic service worker
self.addEventListener('install', (event) => {
  console.log('Service Worker: Installing...');
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  console.log('Service Worker: Activating...');
  return self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  // For MVP, we're not implementing complex caching strategies.
  // This basic fetch handler is often enough for PWA registration.
  // console.log('Service Worker: Fetching', event.request.url);
  // event.respondWith(fetch(event.request));
});
