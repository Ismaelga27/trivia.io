import React from 'react';
import { Player } from '../types';
import Button from './Button';
import { TITLE_FONT_FAMILY, TEXT_NEON_PINK, TEXT_NEON_BLUE, SHADOW_NEON_PINK, SHADOW_NEON_BLUE, BORDER_NEON_PINK, BORDER_NEON_BLUE } from '../constants';

interface ResultsScreenProps {
  players: Player[];
  onPlayAgain: () => void;
  topics: string[]; // Cambiado de topic: string a topics: string[]
}

const ResultsScreen: React.FC<ResultsScreenProps> = ({ players, onPlayAgain, topics }) => {
  let winners: Player[] = [];
  let isTie = false;

  if (players.length > 0) {
    const sortedPlayers = [...players].sort((a, b) => b.score - a.score);
    const maxScore = sortedPlayers[0].score;
    winners = sortedPlayers.filter(player => player.score === maxScore);
    if (winners.length > 1) {
      isTie = true;
    }
  }
  
  let dominantColorForButton: 'pink' | 'blue' = 'pink';
  if (winners.length > 0) {
    const firstWinnerOriginalIndex = players.findIndex(p => p.name === winners[0].name && p.avatarId === winners[0].avatarId);
    dominantColorForButton = firstWinnerOriginalIndex % 2 === 0 ? 'pink' : 'blue';
  }


  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 text-center">
      <h1 className={`${TITLE_FONT_FAMILY} text-5xl md:text-6xl mb-4 ${TEXT_NEON_PINK}`}>
        ¡Resultados!
      </h1>
      <p className="text-lg text-slate-300 mb-8 max-w-xl">Temas: {topics.join(', ')}</p>

      <div className={`w-full max-w-lg p-6 md:p-8 bg-slate-800/80 rounded-xl border ${dominantColorForButton === 'pink' ? BORDER_NEON_PINK + ' ' + SHADOW_NEON_PINK : BORDER_NEON_BLUE + ' ' + SHADOW_NEON_BLUE} mb-10`}>
        {isTie && (
          <h2 className={`text-3xl md:text-4xl font-bold mb-6 ${TEXT_NEON_BLUE}`}>🏆 ¡Es un Empate Múltiple! 🏆</h2>
        )}
        {!isTie && winners.length === 1 && (
          <h2 className={`text-3xl md:text-4xl font-bold mb-6 ${players.findIndex(p=>p.name === winners[0].name && p.avatarId === winners[0].avatarId) % 2 === 0 ? TEXT_NEON_PINK : TEXT_NEON_BLUE}`}>
            🏆 ¡Ganador: {winners[0].avatarId} {winners[0].name}! 🏆
          </h2>
        )}
        {!isTie && winners.length > 1 && ( 
           <h2 className={`text-3xl md:text-4xl font-bold mb-6 ${TEXT_NEON_BLUE}`}>🏆 ¡Ganadores Múltiples! 🏆</h2>
        )}
        
        <div className="space-y-3 text-lg md:text-xl max-h-[40vh] overflow-y-auto pr-2">
          {players.sort((a,b) => b.score - a.score).map((player, index) => {
            const isWinner = winners.some(w => w.name === player.name && w.avatarId === player.avatarId);
            const playerOriginalIndex = players.findIndex(p => p.name === player.name && p.avatarId === player.avatarId); // Find original index for consistent color
            let playerColorClass = playerOriginalIndex % 2 === 0 ? TEXT_NEON_PINK : TEXT_NEON_BLUE;
            let playerBgClass = playerOriginalIndex % 2 === 0 ? 'bg-pink-500/20' : 'bg-cyan-400/20';
            
            if (isWinner) {
               playerColorClass = playerOriginalIndex % 2 === 0 ? TEXT_NEON_PINK : TEXT_NEON_BLUE; // Keep consistent winner color
               playerBgClass = playerOriginalIndex % 2 === 0 ? `bg-pink-600/40 ${BORDER_NEON_PINK} border-2` : `bg-cyan-500/40 ${BORDER_NEON_BLUE} border-2`;
            } else {
               playerBgClass = 'bg-slate-700/50';
            }

            return (
              <div 
                key={`${player.name}-${player.avatarId}-${index}`} 
                className={`p-3 rounded-lg flex justify-between items-center ${playerBgClass} ${isWinner ? 'font-bold scale-105' : ''} transition-all`}
              >
                <div className="flex items-center">
                  <span className="text-3xl mr-3">{player.avatarId}</span>
                  <span className={`truncate max-w-[150px] md:max-w-[200px] ${isWinner ? 'text-white' : playerColorClass}`}>{player.name}</span>
                </div>
                <span className={`font-semibold ${isWinner ? 'text-white' : playerColorClass}`}>{player.score} puntos</span>
              </div>
            );
          })}
        </div>
      </div>

      <Button onClick={onPlayAgain} variant={dominantColorForButton} className="text-xl py-4">
        Jugar de Nuevo
      </Button>
    </div>
  );
};

export default ResultsScreen;