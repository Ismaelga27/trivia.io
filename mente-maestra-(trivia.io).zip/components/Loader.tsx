
import React from 'react';
import { NEON_PINK } from '../constants';

interface LoaderProps {
  message?: string;
}

const Loader: React.FC<LoaderProps> = ({ message = "Cargando..." }) => {
  return (
    <div className="flex flex-col items-center justify-center space-y-4 p-8">
      <div 
        className="w-16 h-16 border-4 rounded-full animate-spin"
        style={{ borderColor: NEON_PINK, borderTopColor: 'transparent' }}
      ></div>
      <p className="text-xl font-semibold" style={{ color: NEON_PINK }}>{message}</p>
    </div>
  );
};

export default Loader;
