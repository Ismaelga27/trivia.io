import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { QuestionData, GeminiQuestionFormat, Difficulty } from '../types';
import { GEMINI_MODEL_TEXT } from '../constants';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.error("API_KEY environment variable not set. Please set it to use the Gemini API.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY || "MISSING_API_KEY" }); 

const shuffleArray = <T,>(array: T[]): T[] => {
  const newArray = [...array];
  for (let i = newArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
  }
  return newArray;
};

export const generateTriviaQuestions = async (
  topics: string[], 
  numQuestions: number,
  difficulty: Difficulty
): Promise<QuestionData[]> => {
  if (!API_KEY || API_KEY === "MISSING_API_KEY") {
    console.error("generateTriviaQuestions called without a valid API_KEY.");
    return Promise.reject(new Error("La clave API de Gemini no está configurada. No se pueden obtener preguntas."));
  }
  
  const topicsString = topics.join("', '");
  const prompt = `
Por favor, genera ${numQuestions} preguntas de trivia relacionadas con LOS SIGUIENTES TEMAS: '${topicsString}'.
Las preguntas deben ser una mezcla aleatoria de los temas proporcionados, sin seguir un orden específico ni una distribución estrictamente equitativa por tema. Sorprende con la variedad y el orden de los temas en las preguntas.
El nivel de dificultad deseado es '${difficulty}'.
La respuesta DEBE SER un array JSON válido. Cada elemento del array debe ser un objeto JSON con la siguiente estructura EXACTA:
{
  "questionText": "<La pregunta>",
  "options": ["<Opción de Respuesta 1>", "<Opción de Respuesta 2>", "<Opción de Respuesta 3>", "<Opción de Respuesta 4>"],
  "correctAnswer": "<El texto de la respuesta correcta, que debe ser una de las cuatro opciones proporcionadas>"
}
Asegúrate de que:
1. La respuesta completa sea SOLAMENTE el array JSON, sin texto adicional, explicaciones o marcadores de formato como \`\`\`json.
2. Todas las cadenas de texto dentro del JSON (como questionText, opciones y correctAnswer) estén correctamente escapadas para ser válidas en JSON (por ejemplo, comillas dobles dentro de las cadenas deben ser escapadas como \\").
3. El campo 'correctAnswer' debe ser idéntico a una de las cadenas en el array 'options'.
4. Las opciones deben incluir tres distractores creíbles y la respuesta correcta.
5. No incluyas comas adicionales después del último elemento en un array o el último par clave-valor en un objeto.
`;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_MODEL_TEXT,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    let jsonStr = response.text.trim();
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
      jsonStr = match[2].trim();
    }
    
    let parsedData: GeminiQuestionFormat[];
    try {
      parsedData = JSON.parse(jsonStr);
    } catch (parseError) {
      console.error("Error al parsear la respuesta JSON de Gemini. Respuesta recibida (primeros 500 caracteres):", jsonStr.substring(0, 500));
      console.error("Detalles del error de parseo:", parseError);
      throw new Error(`Error al interpretar la respuesta de la IA. El formato JSON no es válido. Verifique la consola para más detalles.`);
    }

    if (!Array.isArray(parsedData) || parsedData.length === 0) {
      console.warn("La API de Gemini devolvió un array vacío o no válido. Respuesta parseada:", parsedData);
      throw new Error('La API de Gemini no devolvió un array de preguntas válido.');
    }
    if (parsedData.length < numQuestions) {
        console.warn(`Se solicitaron ${numQuestions} preguntas pero solo se recibieron ${parsedData.length}.`);
    }

    return parsedData.slice(0, numQuestions).map((q, index) => {
      if (!q.questionText || !q.options || q.options.length !== 4 || !q.correctAnswer) {
        console.error('Pregunta mal formada de la API:', q);
        throw new Error(`La pregunta ${index + 1} recibida de la API está mal formada.`);
      }
      if (!q.options.includes(q.correctAnswer)) {
        console.error('La respuesta correcta no está en las opciones para la pregunta:', q.questionText, 'Opciones:', q.options, 'Respuesta esperada:', q.correctAnswer);
         throw new Error(`La respuesta correcta para la pregunta "${q.questionText}" no se encuentra entre las opciones proporcionadas.`);
      }
      return {
        ...q,
        id: `q-${Date.now()}-${index}`,
        options: shuffleArray(q.options),
      };
    });

  } catch (error) {
    console.error("Error detallado al generar preguntas de trivia:", error);
    if (error instanceof Error) {
        if (error.message.startsWith("Error al interpretar la respuesta de la IA") || 
            error.message.startsWith("La API de Gemini no devolvió") ||
            error.message.startsWith("La pregunta") ||
            error.message.startsWith("La respuesta correcta para la pregunta")) {
          throw error;
        }
        throw new Error(`Error al contactar la IA: ${error.message}`);
    }
    throw new Error("Error desconocido al contactar la IA.");
  }
};