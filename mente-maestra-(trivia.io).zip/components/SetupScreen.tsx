import React, { useState, useEffect } from 'react';
import Button from './Button';
import { 
  GameSettings, 
  Difficulty, 
  PlayerSetupData 
} from '../types';
import { 
  AVATARS, 
  DEFAULT_AVATAR, 
  TITLE_FONT_FAMILY, 
  TEXT_NEON_PINK, 
  TEXT_NEON_BLUE,
  BORDER_NEON_PINK, 
  BORDER_NEON_BLUE,
  MIN_PLAYERS, 
  MAX_PLAYERS, 
  DEFAULT_NUM_PLAYERS,
  MIN_ROUNDS_PER_PLAYER, 
  MAX_ROUNDS_PER_PLAYER, 
  DEFAULT_NUM_ROUNDS_PER_PLAYER,
  PLAYER_DEFAULT_NAME_PREFIX,
  MIN_TOPICS,
  MAX_TOPICS
} from '../constants';

interface SetupScreenProps {
  onStartGameSetup: (settings: GameSettings, playersData: PlayerSetupData[]) => void;
}

const SetupScreen: React.FC<SetupScreenProps> = ({ onStartGameSetup }) => {
  const [step, setStep] = useState(1); 

  // Game Settings State
  const [currentTopicInput, setCurrentTopicInput] = useState<string>('');
  const [selectedTopics, setSelectedTopics] = useState<string[]>([]);
  const [numPlayers, setNumPlayers] = useState<number>(DEFAULT_NUM_PLAYERS);
  const [numRounds, setNumRounds] = useState<number>(DEFAULT_NUM_ROUNDS_PER_PLAYER);
  const [difficulty, setDifficulty] = useState<Difficulty>(Difficulty.MEDIUM);

  // Player Customization State
  const [playersData, setPlayersData] = useState<PlayerSetupData[]>([]);

  useEffect(() => {
    const initialPlayers: PlayerSetupData[] = Array.from({ length: numPlayers }, (_, i) => ({
      name: `${PLAYER_DEFAULT_NAME_PREFIX} ${i + 1}`,
      avatarId: AVATARS[i % AVATARS.length] || DEFAULT_AVATAR,
    }));
    setPlayersData(initialPlayers);
  }, [numPlayers]);

  const handleAddTopic = () => {
    const newTopic = currentTopicInput.trim();
    if (newTopic && selectedTopics.length < MAX_TOPICS && !selectedTopics.includes(newTopic)) {
      setSelectedTopics([...selectedTopics, newTopic]);
      setCurrentTopicInput('');
    } else if (selectedTopics.length >= MAX_TOPICS) {
      alert(`Puedes seleccionar un máximo de ${MAX_TOPICS} temas.`);
    } else if (selectedTopics.includes(newTopic)) {
      alert("Este tema ya ha sido añadido.");
    }
  };

  const handleRemoveTopic = (topicToRemove: string) => {
    setSelectedTopics(selectedTopics.filter(topic => topic !== topicToRemove));
  };

  const handlePlayerNameChange = (index: number, name: string) => {
    const updatedPlayers = [...playersData];
    updatedPlayers[index].name = name;
    setPlayersData(updatedPlayers);
  };

  const handleAvatarChange = (index: number, avatarId: string) => {
    const updatedPlayers = [...playersData];
    updatedPlayers[index].avatarId = avatarId;
    setPlayersData(updatedPlayers);
  };

  const goToPlayerCustomization = () => {
    if (selectedTopics.length >= MIN_TOPICS && selectedTopics.length <= MAX_TOPICS) {
      setStep(2);
    } else {
      alert(`Por favor, selecciona entre ${MIN_TOPICS} y ${MAX_TOPICS} temas.`);
    }
  };

  const startGame = () => {
    const finalPlayersData = playersData.map((p, i) => ({
        ...p,
        name: p.name.trim() === '' ? `${PLAYER_DEFAULT_NAME_PREFIX} ${i + 1}` : p.name.trim(),
    }));

    onStartGameSetup(
      { topics: selectedTopics, numPlayers, numRounds, difficulty },
      finalPlayersData
    );
  };

  const inputClass = `w-full p-3 bg-slate-800 border ${BORDER_NEON_PINK} rounded-md focus:ring-2 focus:ring-pink-500 focus:border-transparent outline-none placeholder-gray-500 text-white`;
  const selectClass = `${inputClass} appearance-none`;

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 text-center">
      <h1 className={`${TITLE_FONT_FAMILY} text-5xl md:text-6xl mb-2`}>
        triv<span className={TEXT_NEON_PINK}>IA</span>.io
      </h1>
      <p className="text-slate-400 mb-10 text-lg">Tu Duelo de Trivia Infinito</p>
      
      {step === 1 && (
        <form onSubmit={(e) => { e.preventDefault(); goToPlayerCustomization(); }} className="w-full max-w-lg space-y-6">
          <h2 className={`${TITLE_FONT_FAMILY} text-3xl mb-4 ${TEXT_NEON_BLUE}`}>Configura tu Partida</h2>
          <div>
            <label htmlFor="topicInput" className={`block text-lg font-medium mb-2 ${TEXT_NEON_PINK}`}>
              Añade Temas ({selectedTopics.length}/{MAX_TOPICS})
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                id="topicInput"
                value={currentTopicInput}
                onChange={(e) => setCurrentTopicInput(e.target.value)}
                placeholder="Ej: Historia, Ciencia..."
                className={inputClass}
                onKeyPress={(e) => { if (e.key === 'Enter') { e.preventDefault(); handleAddTopic();}}}
              />
              <Button type="button" onClick={handleAddTopic} variant="blue" className="px-4" disabled={selectedTopics.length >= MAX_TOPICS}>
                Añadir
              </Button>
            </div>
            <div className="mt-3 flex flex-wrap gap-2 items-center justify-center">
              {selectedTopics.map(topic => (
                <span key={topic} className={`flex items-center gap-2 text-sm bg-slate-700 ${TEXT_NEON_BLUE} px-3 py-1 rounded-full border ${BORDER_NEON_BLUE}`}>
                  {topic}
                  <button 
                    type="button" 
                    onClick={() => handleRemoveTopic(topic)} 
                    className="text-red-400 hover:text-red-300 font-bold"
                    aria-label={`Eliminar tema ${topic}`}
                  >
                    &times;
                  </button>
                </span>
              ))}
            </div>
            {selectedTopics.length < MIN_TOPICS && <p className="text-xs text-red-400 mt-1">Debes añadir al menos {MIN_TOPICS} tema.</p>}
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label htmlFor="numPlayers" className={`block text-lg font-medium mb-2 ${TEXT_NEON_PINK}`}>
                Jugadores
              </label>
              <select 
                id="numPlayers" 
                value={numPlayers} 
                onChange={(e) => setNumPlayers(parseInt(e.target.value))} 
                className={selectClass}
              >
                {Array.from({ length: MAX_PLAYERS - MIN_PLAYERS + 1 }, (_, i) => MIN_PLAYERS + i).map(n => (
                  <option key={n} value={n}>{n}</option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="numRounds" className={`block text-lg font-medium mb-2 ${TEXT_NEON_PINK}`}>
                Rondas
              </label>
              <select 
                id="numRounds" 
                value={numRounds} 
                onChange={(e) => setNumRounds(parseInt(e.target.value))} 
                className={selectClass}
              >
                {Array.from({ length: MAX_ROUNDS_PER_PLAYER - MIN_ROUNDS_PER_PLAYER + 1 }, (_, i) => MIN_ROUNDS_PER_PLAYER + i).map(n => (
                  <option key={n} value={n}>{n}</option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="difficulty" className={`block text-lg font-medium mb-2 ${TEXT_NEON_PINK}`}>
                Dificultad
              </label>
              <select 
                id="difficulty" 
                value={difficulty} 
                onChange={(e) => setDifficulty(e.target.value as Difficulty)} 
                className={selectClass}
              >
                {Object.values(Difficulty).map(d => (
                  <option key={d} value={d}>{d}</option>
                ))}
              </select>
            </div>
          </div>
          
          <Button type="submit" variant="pink" className="w-full text-xl py-4" disabled={selectedTopics.length < MIN_TOPICS || selectedTopics.length > MAX_TOPICS}>
            Siguiente: Personalizar Jugadores
          </Button>
        </form>
      )}

      {step === 2 && (
        <div className="w-full max-w-2xl space-y-8">
          <h2 className={`${TITLE_FONT_FAMILY} text-3xl mb-4 ${TEXT_NEON_BLUE}`}>Personaliza los Jugadores</h2>
          <div className="space-y-6 max-h-[60vh] overflow-y-auto pr-2">
            {playersData.map((player, index) => (
              <div key={index} className={`p-4 bg-slate-800 rounded-lg border ${index % 2 === 0 ? BORDER_NEON_PINK : BORDER_NEON_BLUE}`}>
                <h3 className={`text-xl font-semibold mb-3 ${index % 2 === 0 ? TEXT_NEON_PINK : TEXT_NEON_BLUE}`}>Jugador {index + 1}</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-end">
                  <div>
                    <label htmlFor={`player${index}Name`} className={`block text-sm font-medium mb-1 ${index % 2 === 0 ? TEXT_NEON_PINK : TEXT_NEON_BLUE}`}>
                      Nombre
                    </label>
                    <input
                      type="text"
                      id={`player${index}Name`}
                      value={player.name}
                      onChange={(e) => handlePlayerNameChange(index, e.target.value)}
                      placeholder={`${PLAYER_DEFAULT_NAME_PREFIX} ${index + 1}`}
                      className={inputClass.replace(BORDER_NEON_PINK, index % 2 === 0 ? BORDER_NEON_PINK : BORDER_NEON_BLUE)}
                    />
                  </div>
                  <div>
                    <label className={`block text-sm font-medium mb-1 ${index % 2 === 0 ? TEXT_NEON_PINK : TEXT_NEON_BLUE}`}>
                      Avatar
                    </label>
                    <div className="flex flex-wrap gap-2 p-2 bg-slate-700/50 rounded-md justify-center">
                      {AVATARS.map(avatar => (
                        <button
                          key={avatar}
                          title={avatar}
                          onClick={() => handleAvatarChange(index, avatar)}
                          className={`text-3xl p-1 rounded-md hover:bg-slate-600 transition-all ${player.avatarId === avatar ? `ring-2 ${index % 2 === 0 ? 'ring-pink-500' : 'ring-cyan-400'} bg-slate-600` : ''}`}
                          aria-label={`Seleccionar avatar ${avatar}`}
                          aria-pressed={player.avatarId === avatar}
                        >
                          {avatar}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="flex gap-4 mt-8">
            <Button type="button" variant="blue" onClick={() => setStep(1)} className="w-1/2 text-lg py-3">
              Volver
            </Button>
            <Button type="button" variant="pink" onClick={startGame} className="w-1/2 text-lg py-3">
              ¡Empezar Duelo!
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default SetupScreen;